#!/bin/bash

#This is the query script. Used to Query CPU usage for particular time ranges.
#Validates the command
#Displays 'help' on usage
#Any invalid data or commands are handled and Proper usage are displayed on screen.

#Navigate to DATA_PATH.If empty directory is given prompt user to provide correct DATA PATH
if [ -z "$1" ] || [ "$1" == " " ];
then
	echo "Please provide proper command.Example-  ./query.sh DATA_PATH"
	exit
fi

#Navigate to proper DATA_PATH provide in command line
cd $1 || exit 

#Valid commands
command1="QUERY"
command2="EXIT"

#while loop flag to continuously take user commands
again=1
while [ $again -eq 1 ]
do 
	echo -n ">"
	read query
	
	#Split and store the fields given in query to respective variables
	IFS=' ' read command ip cpu_id s_date s_time d_date d_time <<< "$query"

	#ignore case.Accept both QUERY,query or EXIT or exit
	shopt -s nocasematch
	
	#if query
	if [[ "$command" == "$command1" ]];
	then
		#validate the fields given in command
		if [ -z "$command" ] || [ -z "$ip" ] || [ -z "$cpu_id" ] || [ -z "$s_date" ] || [ -z "$s_time" ] || [ -z "$d_date" ] || [ -z "$d_time" ];
		then
			echo "Please enter valid command.Type help to see command usage !"
			continue
		fi

		cd ..
		java ServerMonitoringSystem/ExcuteQuery $1 $ip $cpu_id $s_date $s_time $d_date $d_time
		cd $1		
	
		echo "complete!"
	#if EXIT
	elif [[ "$command" == "$command2" ]];
	then
		again=0

	#HELP message to user
	else
		echo "COMMANDS are QUERY or EXIT only!!Please try again "
		echo "Example- QUERY IP CPU_ID start_time end_time"
		echo "IP in the ranges 192.168.1.1 to 1.255, 192.168.2.1 to 2.255, 192.168.3.1 to 3.255, 192.168.4.1 to 4.235"
		echo "CPU_ID is 0 or 1"
		echo "start_time  and end_time are in YYYY-MM-DD HH:MM and start_time < end_time "
		echo "DATA available only for 24 hrs of CPU USAGE for the day 2014-10-31"
	fi
done
echo ""
